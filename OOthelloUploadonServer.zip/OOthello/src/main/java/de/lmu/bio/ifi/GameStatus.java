package de.lmu.bio.ifi;

public enum GameStatus {
	RUNNING,
	DRAW,
	PLAYER_1_WON,
	PLAYER_2_WON;
}

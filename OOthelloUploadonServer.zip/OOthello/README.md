# Template repository for ProPra

This repository contains the template code for the Othello task.

### Tests
Automatically check your model for correctness by creating the "verify/model" branch.
The model class must implement the Game interface.

### Submission
Submit your code for grading by creating the "submission/model" (for the model/datastructure submission) and "submission/gui" (for the user interface submission) branch.
